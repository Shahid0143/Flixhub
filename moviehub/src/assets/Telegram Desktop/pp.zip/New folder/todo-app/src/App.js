// src/App.js
import React from 'react';
import { ChakraProvider, Box, VStack } from '@chakra-ui/react';
import { Provider } from 'react-redux';
import TodoList from './components/TodoList';
import TodoForm from './components/TodoForm';
import TodoFilter from './components/TodoFilter';
import ThemeSwitcher from './components/ThemeSwitcher';
import store from './store';

const App = () => {
  return (
    <Provider store={store}>
      <ChakraProvider>
        <Box maxW="400px" m="auto" p={4}>
          <VStack spacing={4}>
            <ThemeSwitcher />
            <TodoForm />
            <TodoList />
            <TodoFilter />
          </VStack>
        </Box>
      </ChakraProvider>
    </Provider>
  );
};

export default App;
