// src/components/TodoForm.js
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { Box, Input, Button } from '@chakra-ui/react';
import { addTodo } from '../features/todos/todosSlice';

const TodoForm = () => {
  const dispatch = useDispatch();
  const [todoText, setTodoText] = useState('');

  const handleSubmit = e => {
    e.preventDefault();
    if (todoText.trim() === '') {
      return;
    }
    dispatch(addTodo({
      text: todoText,
      completed: false,
    }));
    setTodoText('');
  };

  return (
    <Box as="form" mt={4} onSubmit={handleSubmit}>
      <Input
        placeholder="Add a new todo"
        value={todoText}
        onChange={e => setTodoText(e.target.value)}
      />
      <Button type="submit" mt={2} colorScheme="teal">
        Add Todo
      </Button>
    </Box>
  );
};

export default TodoForm;
