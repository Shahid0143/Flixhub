// src/components/TodoFilter.js
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Box, ButtonGroup, Button } from '@chakra-ui/react';
import { setFilter } from '../features/todos/todosSlice';


const TodoFilter = () => {
  const dispatch = useDispatch();
  const activeFilter = useSelector(state => state.filter);

  const handleFilterChange = filter => {
    dispatch(setFilter(filter));
  };

  return (
    <Box mt={4}>
      <ButtonGroup>
        <Button
          colorScheme={activeFilter === 'all' ? 'teal' : 'gray'}
          onClick={() => handleFilterChange('all')}
        >
          All
        </Button>
        <Button
          colorScheme={activeFilter === 'active' ? 'teal' : 'gray'}
          onClick={() => handleFilterChange('active')}
        >
          Active
        </Button>
        <Button
          colorScheme={activeFilter === 'completed' ? 'teal' : 'gray'}
          onClick={() => handleFilterChange('completed')}
        >
          Completed
        </Button>
      </ButtonGroup>
    </Box>
  );
};

export default TodoFilter;
