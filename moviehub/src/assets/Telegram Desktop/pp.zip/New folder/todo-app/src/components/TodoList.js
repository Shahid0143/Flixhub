// src/components/TodoList.js
import React from 'react';
import { useSelector } from 'react-redux';
import { Box, Text } from '@chakra-ui/react';
import TodoItem from './TodoItem';

const TodoList = () => {
  const todos = useSelector(state => {
    const { todos, filter } = state;
    switch (filter) {
      case 'active':
        return todos.filter(todo => !todo.completed);
      case 'completed':
        return todos.filter(todo => todo.completed);
      default:
        return todos;
    }
  });

  const todosCount = todos.length;

  return (
    <Box mt={4}>
      <Text mb={2}>{todosCount} {todosCount === 1 ? 'todo' : 'todos'}</Text>
      {todos.map(todo => (
        <TodoItem key={todo.id} todo={todo} />
      ))}
    </Box>
  );
};

export default TodoList;
