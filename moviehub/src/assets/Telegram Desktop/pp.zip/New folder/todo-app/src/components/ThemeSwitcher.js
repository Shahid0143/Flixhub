// src/components/ThemeSwitcher.js
import React from 'react';
import { useColorMode, IconButton } from '@chakra-ui/react';
import { FaSun, FaMoon } from 'react-icons/fa';

const ThemeSwitcher = () => {
  const { colorMode, toggleColorMode } = useColorMode();
  const isDark = colorMode === 'dark';

  return (
    <IconButton
      icon={isDark ? <FaSun /> : <FaMoon />}
      aria-label="Toggle Theme"
      onClick={toggleColorMode}
    />
  );
};

export default ThemeSwitcher;
