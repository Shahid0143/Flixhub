// src/components/TodoItem.js
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import {
  Box,
  Text,
  Checkbox,
  IconButton,
  Input,
  useColorModeValue,
} from '@chakra-ui/react';
import { MdDelete, MdEdit, MdDone } from 'react-icons/md';
import { toggleComplete, deleteTodo, updateTodo } from '../features/todos/todosSlice';

const TodoItem = ({ todo }) => {
  const dispatch = useDispatch();
  const [editText, setEditText] = useState(todo.text);
  const [editMode, setEditMode] = useState(false);

  const handleToggleComplete = () => {
    dispatch(toggleComplete(todo.id));
  };

  const handleDelete = () => {
    dispatch(deleteTodo(todo.id));
  };

  const handleEdit = () => {
    setEditMode(true);
  };

  const handleSave = () => {
    if (editText.trim() === '') {
      return;
    }
    dispatch(updateTodo({
      id: todo.id,
      text: editText,
    }));
    setEditMode(false);
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setEditMode(false);
  };

  const textDecoration = todo.completed ? 'line-through' : 'none';
  const iconColor = useColorModeValue('gray.600', 'gray.300');

  return (
    <Box
      display="flex"
      alignItems="center"
      justifyContent="space-between"
      mb={2}
    >
      <Checkbox isChecked={todo.completed} onChange={handleToggleComplete}>
        {!editMode ? (
          <Text textDecoration={textDecoration}>{todo.text}</Text>
        ) : (
          <Input
            value={editText}
            onChange={e => setEditText(e.target.value)}
            autoFocus
          />
        )}
      </Checkbox>
      {!editMode ? (
        <>
          <IconButton
            icon={<MdEdit />}
            aria-label="Edit"
            variant="ghost"
            color={iconColor}
            onClick={handleEdit}
          />
          <IconButton
            icon={<MdDelete />}
            aria-label="Delete"
            variant="ghost"
            color={iconColor}
            onClick={handleDelete}
          />
        </>
      ) : (
        <>
          <IconButton
            icon={<MdDone />}
            aria-label="Save"
            variant="ghost"
            color={iconColor}
            onClick={handleSave}
          />
          <IconButton
            icon={<MdDelete />}
            aria-label="Cancel"
            variant="ghost"
            color={iconColor}
            onClick={handleCancel}
          />
        </>
      )}
    </Box>
  );
};

export default TodoItem;
